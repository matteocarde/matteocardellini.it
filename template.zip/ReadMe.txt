Responsive Resume/CV/Portfolio Template

Theme name:
=======================================================================
Sphere

Theme version:
=======================================================================
v1.1

Release Date:
=======================================================================
13 Dec 2016

Author: 
=======================================================================
Xiaoying Riley at 3rd Wave Media

Contact:
=======================================================================
Web: http://themes.3rdwavemedia.com/
Email: themes@3rdwavemedia.com
Facebook: https://www.facebook.com/3rdwavethemes/
Twitter: 3rdwave_themes
